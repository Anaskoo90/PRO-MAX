# Developer Experience

Tooling
- Hot reload
- Linting
- Formatting
- Storybook
- CI validation
