# Progressive Web App

Features
- Offline cache
- Installable app
- Background sync
- Push notifications
- Service workers
