# Frontend Performance

Goals
- Fast initial load
- Code splitting
- Lazy loading
- Asset optimization
- Image optimization
- Bundle analysis
