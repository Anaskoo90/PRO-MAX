# Frontend Testing

Testing Levels
- Unit
- Component
- Integration
- End-to-End
- Visual regression
