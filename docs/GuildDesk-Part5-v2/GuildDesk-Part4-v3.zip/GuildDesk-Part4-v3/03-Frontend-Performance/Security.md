# Frontend Security

Controls
- CSP
- XSS protection
- CSRF mitigation
- Secure cookies
- Trusted Types
