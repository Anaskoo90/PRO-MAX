# GuildDesk Part 4

Frontend Architecture & User Experience - v3.
